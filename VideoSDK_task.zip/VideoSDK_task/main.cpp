#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
using namespace std;

class Account {
protected:
    string account_number;
    float balance;
    vector<string> transaction_history; 

public:
    Account(string acc_num, float initial_balance) : account_number(acc_num), balance(initial_balance) {}
    virtual ~Account() {}

    virtual void deposit(float amount) {
        balance += amount;
        transaction_history.push_back("Deposit: " + to_string(amount));
    }

    virtual bool withdraw(float amount) {
        if (balance >= amount) {
            balance -= amount;
            transaction_history.push_back("Withdrawal: " + to_string(amount));
            return true;
        } else {
            cout << "Insufficient funds!" << endl;
            return false;
        }
    }

    float get_balance() {
        return balance;
    }

    virtual void transfer(float amount, Account &destination) {
        if (withdraw(amount)) {
            destination.deposit(amount);
            transaction_history.push_back("Transfer: " + to_string(amount) + " to " + destination.get_account_number());
        }
    }

    string get_account_number() {
        return account_number;
    }

    virtual void show_transaction_history()  {
        cout << "Transaction history for account: " << account_number << endl;
        for ( auto &t : transaction_history) {
            cout << t << endl;
        }
    }
};

class SavingsAccount : public Account {
private:
    float interest_rate;

public:
    SavingsAccount(string acc_num, float initial_balance, float rate) : Account(acc_num, initial_balance), interest_rate(rate) {}

    void apply_interest() {
        float interest = balance * interest_rate;
        deposit(interest);
        transaction_history.push_back("Interest applied: " + to_string(interest));
    }
};

class CheckingAccount : public Account {
private:
    float overdraft_limit;

public:
    CheckingAccount(string acc_num, float initial_balance, float overdraft) : Account(acc_num, initial_balance), overdraft_limit(overdraft) {}

    bool withdraw(float amount) override {
        if (balance + overdraft_limit >= amount) {
            balance -= amount;
            transaction_history.push_back("Withdrawal (Overdraft allowed): " + to_string(amount));
            return true;
        } else {
            cout << "Withdrawal exceeds overdraft limit!" << endl;
            return false;
        }
    }
};

void display_menu() {
    cout << "\n--- Banking System Menu ---\n";
    cout << "1. Create Savings Account\n";
    cout << "2. Create Checking Account\n";
    cout << "3. Deposit Money\n";
    cout << "4. Withdraw Money\n";
    cout << "5. Transfer Money\n";
    cout << "6. Show Transaction History\n";
    cout << "7. Apply Interest (Savings Account)\n";
    cout << "8. Show Balance\n";
    cout << "9. Exit\n";
    cout << "Choose an option: ";
}

int main() {
    unordered_map<string, Account*> accounts;  
    int choice;
    
    do {
        display_menu();
        cin >> choice;

        string account_number;
        float amount;
        switch (choice) {
            case 1: {  
                string acc_num;
                float initial_balance, interest_rate;
                cout << "Enter Account Number: ";
                cin >> acc_num;
                cout << "Enter Initial Balance: ";
                cin >> initial_balance;
                cout << "Enter Interest Rate: ";
                cin >> interest_rate;
                accounts[acc_num] = new SavingsAccount(acc_num, initial_balance, interest_rate);
                cout << "Savings Account created!\n";
                break;
            }
            case 2: { 
                string acc_num;
                float initial_balance, overdraft_limit;
                cout << "Enter Account Number: ";
                cin >> acc_num;
                cout << "Enter Initial Balance: ";
                cin >> initial_balance;
                cout << "Enter Overdraft Limit: ";
                cin >> overdraft_limit;
                accounts[acc_num] = new CheckingAccount(acc_num, initial_balance, overdraft_limit);
                cout << "Checking Account created!\n";
                break;
            }
            case 3: { 
                cout << "Enter Account Number: ";
                cin >> account_number;
                if (accounts.find(account_number) != accounts.end()) {
                    cout << "Enter Amount to Deposit: ";
                    cin >> amount;
                    accounts[account_number]->deposit(amount);
                    cout << "Deposit successful!\n";
                } else {
                    cout << "Account not found.\n";
                }
                break;
            }
            case 4: {  
                cout << "Enter Account Number: ";
                cin >> account_number;
                if (accounts.find(account_number) != accounts.end()) {
                    cout << "Enter Amount to Withdraw: ";
                    cin >> amount;
                    if (accounts[account_number]->withdraw(amount)) {
                        cout << "Withdrawal successful!\n";
                    }
                } else {
                    cout << "Account not found.\n";
                }
                break;
            }
            case 5: { 
                string dest_account;
                cout << "Enter Your Account Number: ";
                cin >> account_number;
                if (accounts.find(account_number) != accounts.end()) {
                    cout << "Enter Destination Account Number: ";
                    cin >> dest_account;
                    if (accounts.find(dest_account) != accounts.end()) {
                        cout << "Enter Amount to Transfer: ";
                        cin >> amount;
                        accounts[account_number]->transfer(amount, *accounts[dest_account]);
                        cout << "Transfer successful!\n";
                    } else {
                        cout << "Destination account not found.\n";
                    }
                } else {
                    cout << "Your account not found.\n";
                }
                break;
            }
            case 6: { 
                cout << "Enter Account Number: ";
                cin >> account_number;
                if (accounts.find(account_number) != accounts.end()) {
                    accounts[account_number]->show_transaction_history();
                } else {
                    cout << "Account not found.\n";
                }
                break;
            }
            case 7: {  
                cout << "Enter Savings Account Number: ";
                cin >> account_number;
                SavingsAccount* savings = dynamic_cast<SavingsAccount*>(accounts[account_number]);
                if (savings) {
                    savings->apply_interest();
                    cout << "Interest applied.\n";
                } else {
                    cout << "Not a Savings Account.\n";
                }
                break;
            }
            case 8: {  
                cout << "Enter Account Number: ";
                cin >> account_number;
                if (accounts.find(account_number) != accounts.end()) {
                    cout << "Balance: " << accounts[account_number]->get_balance() << endl;
                } else {
                    cout << "Account not found.\n";
                }
                break;
            }
            case 9: {
                cout << "Exiting program.\n";
                break;
            }
            default:
                cout << "Invalid option. Please try again.\n";
                break;
        }
    } while (choice != 9);

    for (auto &pair : accounts) {
        delete pair.second;
    }
    
    return 0;
}