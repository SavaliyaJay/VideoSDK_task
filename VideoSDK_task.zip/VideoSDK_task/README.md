Name: Jay Savaliya
email: work.jaysavaliya@gmail.com
contact: 7096559963

TASK: BANKING_SYSTEM
Following are the steps to consider:
inside the folder of VideoSDK_task there is a main.cpp file
make sure you have a gcc compiler installed on your device
you can use any editor like visual studio code or devc++
you can also use online editor
and there is an another pdf file attached named screen_shot of task which has screen shot of the task (output).